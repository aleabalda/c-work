package exC;

import java.util.ArrayList;

public interface Observer {
    public void update(ArrayList<Double> arr);
}
