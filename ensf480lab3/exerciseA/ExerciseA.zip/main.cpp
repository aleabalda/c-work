/*
 * File Name: main.cpp
 * Assignment: Lab 2 Exercise B
 * Lab Section: B02
 * Completed by: Alessandro Baldassarre
 * Submission Date: Wednesday, October 2, 2:00 PM
 */

#include "graphicsWorld.h"
#include <iostream>
using namespace std;

int main(void) // Main to test all files by creating GraphicsWorld item and running "run()" function.
{
    GraphicsWorld item;
    item.run();

    return 0;
}